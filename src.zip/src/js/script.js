function login() {
    let name = document.getElementById("login-name").value
    let surname = document.getElementById("login-surname").value
    let email = document.getElementById("login-email").value
    let message = document.getElementById("login-message").value
}

function generate_code() {
    return;
}