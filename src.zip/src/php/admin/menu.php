
<div class="menu-panel">
  <div class="menu-item" onclick="showPanel('requests')">
    <img src="../../images/DeliveryRequest(Logo).png" alt="Requests" />
    <span>Delivery Requests & Status</span>
  </div>
  <div class="menu-item" onclick="showPanel('inquiries')">
    <img src="../../images/ClientInquiries(Logo).png" alt="Inquiries" />
    <span>Client Inquiries</span>
  </div>
  <div class="menu-item" onclick="showPanel('clients')">
    <img src="../../images/ClientLists(Logo).png" alt="Clients" />
    <span>Client Lists</span>
  </div>
  <a class="menu-item" style="text-decoration: none;" href="../logout.php">
        <img src="../../images/log_outLogo.png" alt="Log Out" />
    <span>Log Out</span>
  </a>
</div>